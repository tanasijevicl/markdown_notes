/**
 * @file    main.c
 * @author  Lazar Tanasijevic
 * @date    2025
 * @brief   SRV Project
 *
 * - Starting ADC conversion on every 1000ms (xTaskTimer)
 * - Delayed ADC interrupt processing using queue (xADCMsgQueue)
 * - Calculation of the average value of the last 16 samples (xTask1)
 * - Forwarding the calculated value via direct task notification (xTask1 -> xTask2, xTask3)
 * - Delayed UART interrupt processing using queue (xUARTCharQueue)
 * - Giving a semaphore of a specific task depending on the received number (xTask2Sem, xTask3Sem)
 * - Reading the task notification value (xTask2, xTask3)
 * - Forwarding the value to be printed on a 7seg display (xTask2Sem, xTask3Sem -> xTaskLED)
 *   using queue (xLEDValueQueue)
 */

/* Standard includes */
#include <stdio.h>
#include <stdlib.h>

/* FreeRTOS includes */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

/* Hardware includes */
#include "msp430.h"

/* User's includes */
#include "ETF5529_HAL/hal_ETF_5529.h"

#define ADC_CONVERSION_PERIOD_MS 1000
#define ADC_SAMPLE_NUM 16
#define ULONG_MAX 0xFFFFFFFF

/* Typedefs */
typedef enum {
    A0, A1
} ADCChannel_t;     // ADC Channels

typedef struct {
    ADCChannel_t channel;   // Channel
    uint16_t value;         // Sample value
} ADCMessage_t;     // ADC Message structure

typedef struct {
    uint8_t curr_pos;                 // Index in circular buffer
    uint8_t sample[ADC_SAMPLE_NUM];   // Last 16 samples
    uint32_t sum_val;                 // Current sum of samples
    uint8_t count;                    // Number of valid samples
} ADCSample_t;      // ADC Sample structure

/* Task priorities */
#define mainTIMER_TASK_PRIO ( 5 )   // "Timer Task" priority
#define mainTASK1_PRIO      ( 4 )   // "Task 1" priority
#define mainTASK2_PRIO      ( 3 )   // "Task 2" priority
#define mainTASK3_PRIO      ( 3 )   // "Task 3" priority
#define mainUART_TASK_PRIO  ( 2 )   // "UART Task" priority
#define mainLED_TASK_PRIO   ( 1 )   // "LED Task" priority

/* Queue lengths */
#define mainADC_MSG_QUEUE_LENGTH    20
#define mainUART_CHAR_QUEUE_LENGTH  5
#define mainLED_VALUE_QUEUE_LENGTH  5

/* Task functions */
static void xTaskTimer(void* pvParameters);
static void xTask1(void* pvParameters);
static void xTask2(void* pvParameters);
static void xTask3(void* pvParameters);
static void xTaskUART(void* pvParameters);
static void xTaskLED(void* pvParameters);

/* Helper functions */
static void prvSetupHardware();
static uint32_t samplesAvg(ADCSample_t* adc, uint8_t new_value);

/* Queues */
QueueHandle_t  xADCMsgQueue;      // Queue for ADC messages
QueueHandle_t  xUARTCharQueue;    // Queue for received characters from UART
QueueHandle_t  xLEDValueQueue;    // Queue for sample values for writing on the display

/* Semaphores */
SemaphoreHandle_t xTask2Sem;    // Semaphore for Task2 notification
SemaphoreHandle_t xTask3Sem;    // Semaphore for Task3 notification

/* Task handles */
TaskHandle_t  xTask2Handle;     // Task2 handle used for direct notification
TaskHandle_t  xTask3Handle;     // Task3 handle used for direct notification

/**
 * @brief main function
 */
void main()
{
    /* Configure peripherals */
    prvSetupHardware();

    /* Create tasks */
    xTaskCreate( xTaskTimer,
                 "Timer Task",
                 configMINIMAL_STACK_SIZE,
                 NULL,
                 mainTIMER_TASK_PRIO,
                 NULL
               );
    xTaskCreate( xTask1,
                 "Task 1",
                 configMINIMAL_STACK_SIZE,
                 NULL,
                 mainTASK1_PRIO,
                 NULL
               );
    xTaskCreate( xTask2,
                 "Task 2",
                 configMINIMAL_STACK_SIZE,
                 NULL,
                 mainTASK2_PRIO,
                 &xTask2Handle
               );
    xTaskCreate( xTask3,
                 "Task 3",
                 configMINIMAL_STACK_SIZE,
                 NULL,
                 mainTASK3_PRIO,
                 &xTask3Handle
               );
    xTaskCreate( xTaskUART,
                 "UART Task",
                 configMINIMAL_STACK_SIZE,
                 NULL,
                 mainUART_TASK_PRIO,
                 NULL
               );
    xTaskCreate( xTaskLED,
                 "LED Display Task",
                 configMINIMAL_STACK_SIZE,
                 NULL,
                 mainLED_TASK_PRIO,
                 NULL
               );

    /* Create queues */
    xADCMsgQueue   = xQueueCreate(mainADC_MSG_QUEUE_LENGTH,   sizeof(ADCMessage_t));
    xUARTCharQueue = xQueueCreate(mainUART_CHAR_QUEUE_LENGTH, sizeof(char));
    xLEDValueQueue = xQueueCreate(mainLED_VALUE_QUEUE_LENGTH, sizeof(uint32_t));

    /* Create semaphores */
    xTask2Sem = xSemaphoreCreateBinary();
    xTask3Sem = xSemaphoreCreateBinary();

    /* Start the scheduler */
    vTaskStartScheduler();

    for( ;; );
}

/* Task functions */

/**
 * @brief "Timer Task" function
 *
 * This task starts ADC conversion every 1000ms
 */
static void xTaskTimer(void * pvParameters)
{
    TickType_t xLastWakeTime = xTaskGetTickCount(); // Initialize the xLastWakeTime variable
    const TickType_t xPeriod = pdMS_TO_TICKS(ADC_CONVERSION_PERIOD_MS);

    for( ;; )
    {
        ADC12CTL0 &= ~ADC12SC;     // Ensure stop before re-enable
        ADC12CTL0 |= ADC12ENC;     // Re-enable conversions
        ADC12CTL0 |= ADC12SC;      // Start conversion
        vTaskDelayUntil(&xLastWakeTime, xPeriod);   // Wait for the next cycle
    }
}

/**
 * @brief "Task 1" function
 *
 * This task
 */
static void xTask1(void* pvParameters)
{
    ADCMessage_t msg;
    ADCSample_t adcA0 = {0};
    ADCSample_t adcA1 = {0};
    uint32_t avg_val;

    for( ;; )
    {
        xQueueReceive(xADCMsgQueue, &msg, portMAX_DELAY);

        switch (msg.channel)
        {
            case A0:
                avg_val = samplesAvg(&adcA0, msg.value);
                xTaskNotify(xTask2Handle, (uint32_t) avg_val, eSetValueWithOverwrite);
                break;
            case A1:
                avg_val = samplesAvg(&adcA1, msg.value);
                xTaskNotify(xTask3Handle, (uint32_t) avg_val, eSetValueWithOverwrite);
                break;
        }
    }
}

/**
 * @brief "Task 2" function
 *
 * This task reads notification value which forwards to the 7seg display queue
 */
static void xTask2(void* pvParameters)
{
    uint32_t value = 0;

    for ( ;; )
    {
        xSemaphoreTake(xTask2Sem, portMAX_DELAY);
        xTaskNotifyWait(0, 0, &value, 0);
        xQueueSendToBack(xLEDValueQueue, &value, portMAX_DELAY);
    }
}

/**
 * @brief "Task 3" function
 *
 * This task reads notification value which forwards to the 7seg display queue
 */
static void xTask3(void* pvParameters)
{
    uint32_t value = 0;

    for ( ;; )
    {
        xSemaphoreTake(xTask3Sem, portMAX_DELAY);
        xTaskNotifyWait(0, 0, &value, 0);
        xQueueSendToBack(xLEDValueQueue, &value, portMAX_DELAY);
    }
}

/**
 * @brief "UART Task" function
 *
 * This task determines which character is received and based on the
 * value of the character gives the specific task its semaphore
 */

static void xTaskUART(void* pvParameters)
{
    char c = 0;

    for ( ;; )
    {
        xQueueReceive(xUARTCharQueue, &c, portMAX_DELAY);   // Read character from the queue

        switch(c){
            case '2':
                xSemaphoreGive(xTask2Sem);
                break;
            case '3':
                xSemaphoreGive(xTask3Sem);
                break;
            default:
                break;
        }
    }
}

/**
 * @brief "LED Display Task" function
 *
 * This task read data from xDisplayQueue but reading is not blocking.
 * xDisplayQueue is used to send data which will be printed on 7Seg
 * display. After data is received it is decomposed on high and low digit.
 */
static void xTaskLED(void* pvParameters)
{
    uint32_t NewValueToShow = 0;    // New received data
    uint8_t digitHigh = 0;          // High number digit
    uint8_t digitLow = 0;           // Low number digit

    for ( ;; )
    {
        /* Check if new number is received*/
        if(xQueueReceive(xLEDValueQueue, &NewValueToShow, 0) == pdTRUE) {
            digitHigh = NewValueToShow / 10;                // Extract high digit
            digitLow  = NewValueToShow - digitHigh * 10;    // Extract low digit
        }
        HAL_7SEG_DISPLAY_1_ON;
        HAL_7SEG_DISPLAY_2_OFF;
        vHAL7SEGWriteDigit(digitLow);
        vTaskDelay(5);
        HAL_7SEG_DISPLAY_2_ON;
        HAL_7SEG_DISPLAY_1_OFF;
        vHAL7SEGWriteDigit(digitHigh);
        vTaskDelay(5);
    }
}


/* Helper functions */

/**
 * @brief Hardware configuration upon boot
 */
static void prvSetupHardware()
{
    /* Disable global interrupts*/
    taskDISABLE_INTERRUPTS();

    /* Disable the watch-dog. */
    WDTCTL = WDTPW + WDTHOLD;

    hal430SetSystemClock(configCPU_CLOCK_HZ, configLFXT_CLOCK_HZ);

    /* Initialize ADC */
    P6SEL |= BIT0 | BIT1;                   // Configure analog inputs on P6.0 (A0) and P6.1 (A1)
    ADC12CTL0  = ADC12SHT0_2 | ADC12ON;     // Sample time, ADC ON
    ADC12CTL1 = ADC12CONSEQ_1 | ADC12SHP;   // Sequence-of-channels mode, source from the sampling timer
    ADC12MCTL0 = ADC12INCH_0;               // MEM0 -> A0
    ADC12MCTL1 = ADC12INCH_1 | ADC12EOS;    // MEM1 -> A1, end of sequence
    ADC12IE    = BIT0 | BIT1;               // Enable interrupts for MEM0 and MEM1

    /* Initialize UART */
    P4SEL       |= BIT4 + BIT5;             // P4.4, P4.5 = USCI_AA TXD/RXD
    UCA1CTL1    |= UCSWRST;                 // Put state machine in reset
    UCA1CTL1    |= UCSSEL_2;                // SMCLK
    UCA1BRW      = 1041;                    // 1MHz - Baud rate 9600
    UCA1MCTL    |= UCBRS_6 + UCBRF_0;       // Modulation UCBRSx=1, UCBRFx=0
    UCA1CTL1    &= ~UCSWRST;                // Initialize USCI state machine
    UCA1IE      |= UCRXIE;                  // Enable USCI_A1 RX interrupt

    /* Initialize display */
    vHAL7SEGInit();

    /* Enable global interrupts*/
    taskENABLE_INTERRUPTS();
}

/**
 * @brief Helper function samplesAvg()
 *
 * Calculates average sampling value last 16 values
 */
static uint32_t samplesAvg(ADCSample_t* adc, uint8_t new_value)
{
    int32_t diff;

    if (adc->count < ADC_SAMPLE_NUM) {
        adc->sample[adc->curr_pos] = new_value;
        adc->sum_val += new_value;
        adc->count++;
    } else {
        diff = (int32_t)new_value - (int32_t)adc->sample[adc->curr_pos];
        adc->sum_val += diff;
        adc->sample[adc->curr_pos] = new_value;
    }

    adc->curr_pos = (adc->curr_pos + 1) % ADC_SAMPLE_NUM;

    return adc->sum_val / adc->count;
}

/* INTERRUPTS */

/**
 * @brief ADC interrupt routine
 *
 * This routine adds converted data from ADC12MEMx to xADCMsgQueue with channel info (x = 0, 1)
 */
void __attribute__ ( ( interrupt(ADC12_VECTOR) ) ) vADC12ISR(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    ADCMessage_t msg;

    switch(__even_in_range(ADC12IV,34))
    {
        case  0: break;                           // Vector  0:  No interrupt
        case  2: break;                           // Vector  2:  ADC overflow
        case  4: break;                           // Vector  4:  ADC timing overflow
        case  6:                                  // Vector  6:  ADC12IFG0
            /* Channel A0 */
            msg.channel = A0;
            msg.value = (uint16_t)(ADC12MEM0 >> 6);     // Scaling ADC value to fit on two digits representation
            xQueueSendToBackFromISR(xADCMsgQueue, &msg, &xHigherPriorityTaskWoken);
            break;
        case  8:                                  // Vector  8:  ADC12IFG1
            /* Channel A1 */
            msg.channel = A1;
            msg.value = (uint16_t)(ADC12MEM1 >> 6);     // Scaling ADC value to fit on two digits representation
            xQueueSendToBackFromISR(xADCMsgQueue, &msg, &xHigherPriorityTaskWoken);
            break;
        case 10: break;                           // Vector 10:  ADC12IFG2
        case 12: break;                           // Vector 12:  ADC12IFG3
        case 14: break;                           // Vector 14:  ADC12IFG4
        case 16: break;                           // Vector 16:  ADC12IFG5
        case 18: break;                           // Vector 18:  ADC12IFG6
        case 20: break;                           // Vector 20:  ADC12IFG7
        case 22: break;                           // Vector 22:  ADC12IFG8
        case 24: break;                           // Vector 24:  ADC12IFG9
        case 26: break;                           // Vector 26:  ADC12IFG10
        case 28: break;                           // Vector 28:  ADC12IFG11
        case 30: break;                           // Vector 30:  ADC12IFG12
        case 32: break;                           // Vector 32:  ADC12IFG13
        case 34: break;                           // Vector 34:  ADC12IFG14
        default: break;
    }

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);     // Trigger scheduler if higher priority task is woken
}

/**
 * @brief UART interrupt routine
 *
 * This routine adds received data from UCA1RXBUF to xUARTCharQueue
 */
void __attribute__ ( ( interrupt( USCI_A1_VECTOR ) ) ) vUARTISR(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    switch(UCA1IV)
    {
        case 0: break;                            // Vector 0 - no interrupt
        case 2: {                                 // Vector 2 - RXIFG
            uint8_t ch = UCA1RXBUF;
            xQueueSendToBackFromISR(xUARTCharQueue, &ch, &xHigherPriorityTaskWoken);
            break;
        }
        case 4: break;                            // Vector 4 - TXIFG
        default: break;
    }

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);    // Trigger scheduler if higher priority task is woken
}
